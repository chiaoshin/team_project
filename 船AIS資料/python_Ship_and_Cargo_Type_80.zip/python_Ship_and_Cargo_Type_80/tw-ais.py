import requests as req
import os
import pandas as pd
import json
from datetime import datetime

# 設定相對路徑
dir_path = 'data_record/json'
csv_path = 'data_record/csv'
# dir_path = './python_Ship_and_Cargo_Type_80/data_record/json'

# 取得當前目錄
current_path = os.getcwd()

# 目標資料夾路徑
target_path = os.path.join(
    current_path, 'python_Ship_and_Cargo_Type_80', 'data_record', 'json')

# 如果沒有資料夾，則建立
if not os.path.exists(target_path):
    os.makedirs(dir_path, exist_ok=True)
    os.makedirs(csv_path, exist_ok=True)


now_str = datetime.now().strftime("%Y-%m-%d %H(%I)%M%S")

try:
    res = req.get('https://mpbais.motcmpb.gov.tw/aismpb/tools/geojsonais.ashx')
except Exception as e:
    print(e)
    # To Do Something

with open(f'{dir_path}/{now_str}-origin-source.json', 'w') as f:
    f.write(res.text)
    f.close()

json_data = json.loads(res.text)

result = {
    "fid": [],
    "IMO_Number": [],
    "Call_Sign": [],
    "ShipName": [],
    "MMSI": [],
    "Navigational_Status": [],
    "SOG": [],
    "Longitude": [],
    "Latitude": [],
    "COG": [],
    "Ship_and_Cargo_Type": [],
    "Record_Time": [],
}

for feature in json_data["features"]:
    if(feature["properties"]["Ship_and_Cargo_Type"] == 80):
        for key, value in feature["properties"].items():
            result[key].append(value)

df = pd.read_json(json.dumps(result))
# print(df)

df.to_csv(f'{csv_path}/{now_str}-resule.csv',
          encoding='utf8', index=False)
